TRM KICKS website starter

1. Open index.html to preview the website.
2. Replace sample product names/prices/photos.
3. In index.html, replace 91XXXXXXXXXX with your WhatsApp number.
4. To make it public on Google, you will need a domain + hosting and then submit the site to Google Search Console.

This starter uses no external libraries and works on mobile.
